using System;
using System.Collections.Generic;

namespace CyberShield
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Alerta> alertas = new List<Alerta>
            {
                new IntrusionRed("ALT001", "192.168.1.50"),
                new MalwareDetectado("ALT002", "C:/Sistema/virus.exe"),
                new IntrusionRed("ALT003", "10.0.0.23")
            };

            foreach (Alerta a in alertas)
            {
                Console.WriteLine(a.DispararProtocolo());
            }

            Console.ReadKey();
        }
    }
}
