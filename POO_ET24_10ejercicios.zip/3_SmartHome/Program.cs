using System;
using System.Collections.Generic;

namespace SmartHome
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Dispositivo> dispositivos = new List<Dispositivo>
            {
                new AspiradoraRobot("Living", 0.6),
                new LamparaInteligente("Dormitorio", "Azul"),
                new AspiradoraRobot("Cocina", 0.4)
            };

            foreach (Dispositivo d in dispositivos)
            {
                Console.WriteLine(d.EjecutarFuncion());
            }

            Console.ReadKey();
        }
    }
}
