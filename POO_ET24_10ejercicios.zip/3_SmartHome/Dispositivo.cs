using System;

namespace SmartHome
{
    public class Dispositivo
    {
        private string habitacion;

        public string Habitacion
        {
            get { return habitacion; }
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentException("La habitación no puede estar vacía.");
                habitacion = value;
            }
        }

        public Dispositivo(string habitacion)
        {
            Habitacion = habitacion;
        }

        public virtual string EjecutarFuncion()
        {
            return $"El dispositivo en {Habitacion} ejecuta su función básica.";
        }
    }
}
