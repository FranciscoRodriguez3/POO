using System;
using System.Collections.Generic;

namespace OrquestaVirtual
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Instrumento> instrumentos = new List<Instrumento>
            {
                new Guitarra("Fender Stratocaster", 6),
                new Piano("Yamaha U3", 88),
                new Guitarra("Ibanez RG", 7)
            };

            foreach (Instrumento i in instrumentos)
            {
                Console.WriteLine(i.TocarNota());
            }

            Console.ReadKey();
        }
    }
}
