using System;

namespace QuickDrop
{
    public class EnvioExpress : Envio
    {
        private int tiempoLimiteHoras;

        public int TiempoLimiteHoras
        {
            get { return tiempoLimiteHoras; }
            set
            {
                if (value <= 0)
                    throw new ArgumentException("El tiempo límite debe ser mayor a 0 horas.");
                tiempoLimiteHoras = value;
            }
        }

        public EnvioExpress(string direccion, int tiempoLimiteHoras) : base(direccion)
        {
            TiempoLimiteHoras = tiempoLimiteHoras;
        }

        public override string ProcesarEntrega()
        {
            return $"Entrega EXPRESS hacia {Direccion}: debe llegar en menos de {TiempoLimiteHoras} horas.";
        }
    }
}
