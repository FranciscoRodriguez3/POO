using System;

namespace SmartHome
{
    public class AspiradoraRobot : Dispositivo
    {
        private double capacidadTanque;

        public double CapacidadTanque
        {
            get { return capacidadTanque; }
            set
            {
                if (value <= 0)
                    throw new ArgumentException("La capacidad del tanque debe ser mayor a 0 litros.");
                capacidadTanque = value;
            }
        }

        public AspiradoraRobot(string habitacion, double capacidadTanque) : base(habitacion)
        {
            CapacidadTanque = capacidadTanque;
        }

        public override string EjecutarFuncion()
        {
            return $"La aspiradora robot limpia {Habitacion} con un tanque de {CapacidadTanque} L.";
        }
    }
}
