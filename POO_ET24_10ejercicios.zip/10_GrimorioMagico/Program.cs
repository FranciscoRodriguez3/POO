using System;
using System.Collections.Generic;

namespace GrimorioMagico
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Hechizo> hechizos = new List<Hechizo>
            {
                new BolaFuego("Ignis Maximus", 800),
                new EscudoHielo("Glacius Protectus", 3),
                new BolaFuego("Flama Menor", 350)
            };

            foreach (Hechizo h in hechizos)
            {
                Console.WriteLine(h.Lanzar());
            }

            Console.ReadKey();
        }
    }
}
