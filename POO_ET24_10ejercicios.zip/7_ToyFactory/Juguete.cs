using System;

namespace ToyFactory
{
    public class Juguete
    {
        private string numeroSerie;

        public string NumeroSerie
        {
            get { return numeroSerie; }
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentException("El número de serie no puede estar vacío.");
                numeroSerie = value;
            }
        }

        public Juguete(string numeroSerie)
        {
            NumeroSerie = numeroSerie;
        }

        public virtual string ProbarJuguete()
        {
            return $"El juguete N°{NumeroSerie} pasa la prueba estándar de calidad.";
        }
    }
}
