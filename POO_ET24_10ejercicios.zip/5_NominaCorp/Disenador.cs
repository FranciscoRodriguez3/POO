namespace NominaCorp
{
    public class Disenador : Empleado
    {
        public string HerramientaFavorita { get; set; }

        public Disenador(string idEmpleado, string herramientaFavorita) : base(idEmpleado)
        {
            HerramientaFavorita = herramientaFavorita;
        }

        public override string Trabajar()
        {
            return $"El diseñador {IdEmpleado} está creando una interfaz en {HerramientaFavorita}.";
        }
    }
}
