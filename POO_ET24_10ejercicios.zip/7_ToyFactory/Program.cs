using System;
using System.Collections.Generic;

namespace ToyFactory
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Juguete> juguetes = new List<Juguete>
            {
                new Muneca("JUG001", "Sintético"),
                new AutoControl("JUG002", 27.5),
                new Muneca("JUG003", "Natural")
            };

            foreach (Juguete j in juguetes)
            {
                Console.WriteLine(j.ProbarJuguete());
            }

            Console.ReadKey();
        }
    }
}
