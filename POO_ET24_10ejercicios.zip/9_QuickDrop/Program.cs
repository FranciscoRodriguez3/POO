using System;
using System.Collections.Generic;

namespace QuickDrop
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Envio> envios = new List<Envio>
            {
                new EnvioExpress("Av. Siempre Viva 742", 24),
                new EnvioFragil("Calle Falsa 123", "Plástico burbuja"),
                new EnvioExpress("Av. Corrientes 1000", 12)
            };

            foreach (Envio e in envios)
            {
                Console.WriteLine(e.ProcesarEntrega());
            }

            Console.ReadKey();
        }
    }
}
