namespace NominaCorp
{
    public class Programador : Empleado
    {
        public string LenguajePrincipal { get; set; }

        public Programador(string idEmpleado, string lenguajePrincipal) : base(idEmpleado)
        {
            LenguajePrincipal = lenguajePrincipal;
        }

        public override string Trabajar()
        {
            return $"El programador {IdEmpleado} está escribiendo código en {LenguajePrincipal}.";
        }
    }
}
