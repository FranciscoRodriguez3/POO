using System;

namespace GrimorioMagico
{
    public class Hechizo
    {
        private string encantamiento;

        public string Encantamiento
        {
            get { return encantamiento; }
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentException("El encantamiento no puede estar vacío.");
                encantamiento = value;
            }
        }

        public Hechizo(string encantamiento)
        {
            Encantamiento = encantamiento;
        }

        public virtual string Lanzar()
        {
            return $"Se lanza el hechizo {Encantamiento} con magia genérica.";
        }
    }
}
