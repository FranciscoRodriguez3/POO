namespace ToyFactory
{
    public class AutoControl : Juguete
    {
        public double Frecuencia { get; set; }

        public AutoControl(string numeroSerie, double frecuencia) : base(numeroSerie)
        {
            Frecuencia = frecuencia;
        }

        public override string ProbarJuguete()
        {
            return $"El auto a control remoto N°{NumeroSerie} se prueba en la frecuencia {Frecuencia} MHz.";
        }
    }
}
