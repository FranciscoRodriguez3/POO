using System;

namespace CitadelDefense
{
    public class Torreta
    {
        private string ubicacion;

        public string Ubicacion
        {
            get { return ubicacion; }
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentException("La ubicación no puede estar vacía.");
                ubicacion = value;
            }
        }

        public Torreta(string ubicacion)
        {
            Ubicacion = ubicacion;
        }

        public virtual string Disparar()
        {
            return $"La torreta en {Ubicacion} dispara su arma genérica.";
        }
    }
}
