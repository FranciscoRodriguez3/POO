using System;
using System.Collections.Generic;

namespace DigitalKitchen
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Plato> platos = new List<Plato>
            {
                new Pizza("Margarita", "Fina"),
                new Ensalada("César", "Mostaza-miel"),
                new Pizza("Napolitana", "Integral")
            };

            foreach (Plato p in platos)
            {
                Console.WriteLine(p.Preparar());
            }

            Console.ReadKey();
        }
    }
}
