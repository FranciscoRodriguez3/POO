using System;

namespace DigitalKitchen
{
    public class Plato
    {
        private string nombrePlato;

        public string NombrePlato
        {
            get { return nombrePlato; }
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentException("El nombre del plato no puede estar vacío.");
                nombrePlato = value;
            }
        }

        public Plato(string nombrePlato)
        {
            NombrePlato = nombrePlato;
        }

        public virtual string Preparar()
        {
            return $"Preparando el plato {NombrePlato} de forma estándar.";
        }
    }
}
