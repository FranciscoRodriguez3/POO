namespace OrquestaVirtual
{
    public class Piano : Instrumento
    {
        public int NumeroTeclas { get; set; }

        public Piano(string modelo, int numeroTeclas) : base(modelo)
        {
            NumeroTeclas = numeroTeclas;
        }

        public override string TocarNota()
        {
            return $"El piano {Modelo} resuena una nota suave usando una de sus {NumeroTeclas} teclas.";
        }
    }
}
