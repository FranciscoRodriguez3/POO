namespace ToyFactory
{
    public class Muneca : Juguete
    {
        public string MaterialCabello { get; set; }

        public Muneca(string numeroSerie, string materialCabello) : base(numeroSerie)
        {
            MaterialCabello = materialCabello;
        }

        public override string ProbarJuguete()
        {
            return $"La muñeca N°{NumeroSerie} se prueba cepillando su cabello de {MaterialCabello}.";
        }
    }
}
