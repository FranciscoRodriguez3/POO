using System;
using System.Collections.Generic;

namespace NominaCorp
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Empleado> empleados = new List<Empleado>
            {
                new Programador("EMP001", "C#"),
                new Disenador("EMP002", "Figma"),
                new Programador("EMP003", "Python")
            };

            foreach (Empleado e in empleados)
            {
                Console.WriteLine(e.Trabajar());
            }

            Console.ReadKey();
        }
    }
}
