using System;

namespace NominaCorp
{
    public class Empleado
    {
        private string idEmpleado;

        public string IdEmpleado
        {
            get { return idEmpleado; }
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentException("El ID de empleado no puede estar vacío.");
                idEmpleado = value;
            }
        }

        public Empleado(string idEmpleado)
        {
            IdEmpleado = idEmpleado;
        }

        public virtual string Trabajar()
        {
            return $"El empleado {IdEmpleado} está realizando sus tareas.";
        }
    }
}
