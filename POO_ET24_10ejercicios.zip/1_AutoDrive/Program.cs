using System;
using System.Collections.Generic;

namespace AutoDrive
{
    class Program
    {
        static void Main(string[] args)
        {
            // Lista de tipo base que guarda objetos de las clases hijas (polimorfismo)
            List<Vehiculo> vehiculos = new List<Vehiculo>
            {
                new AutoElectrico("Tesla", 450),
                new Camioneta("Ford", true),
                new AutoElectrico("Nissan", 300),
                new Camioneta("Toyota", false)
            };

            foreach (Vehiculo v in vehiculos)
            {
                // Cada objeto ejecuta SU PROPIA versión de Arrancar()
                Console.WriteLine(v.Arrancar());
            }

            Console.ReadKey();
        }
    }
}
