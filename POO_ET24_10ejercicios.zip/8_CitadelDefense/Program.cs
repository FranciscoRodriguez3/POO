using System;
using System.Collections.Generic;

namespace CitadelDefense
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Torreta> torretas = new List<Torreta>
            {
                new TorretaLaser("Muralla Norte", 85),
                new Lanzamisiles("Muralla Sur", 12),
                new TorretaLaser("Torre Central", 40)
            };

            foreach (Torreta t in torretas)
            {
                Console.WriteLine(t.Disparar());
            }

            Console.ReadKey();
        }
    }
}
