namespace AutoDrive
{
    public class Camioneta : Vehiculo
    {
        // Propiedad auto-implementada (sin validación especial pedida)
        public bool Traccion4x4 { get; set; }

        public Camioneta(string marca, bool traccion4x4) : base(marca)
        {
            Traccion4x4 = traccion4x4;
        }

        public override string Arrancar()
        {
            string traccion = Traccion4x4 ? "con tracción 4x4 activada" : "con tracción simple";
            return $"La camioneta {Marca} arranca rugiendo {traccion}.";
        }
    }
}
