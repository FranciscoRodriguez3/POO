using System;

namespace AutoDrive
{
    // Clase hija: hereda de Vehiculo y agrega su propia propiedad
    public class AutoElectrico : Vehiculo
    {
        private int autonomia;

        public int Autonomia
        {
            get { return autonomia; }
            set
            {
                if (value <= 0)
                    throw new ArgumentException("La autonomía debe ser mayor a 0 km.");
                autonomia = value;
            }
        }

        // base(marca) llama al constructor de la clase padre
        public AutoElectrico(string marca, int autonomia) : base(marca)
        {
            Autonomia = autonomia;
        }

        // "override" redefine el método de la clase base
        public override string Arrancar()
        {
            return $"El auto eléctrico {Marca} arranca en silencio. Autonomía disponible: {Autonomia} km.";
        }
    }
}
