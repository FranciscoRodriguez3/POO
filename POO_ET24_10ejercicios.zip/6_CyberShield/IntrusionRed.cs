namespace CyberShield
{
    public class IntrusionRed : Alerta
    {
        public string IpOrigen { get; set; }

        public IntrusionRed(string codigo, string ipOrigen) : base(codigo)
        {
            IpOrigen = ipOrigen;
        }

        public override string DispararProtocolo()
        {
            return $"Alerta {Codigo}: intrusión de red detectada desde la IP {IpOrigen}. Bloqueando acceso.";
        }
    }
}
