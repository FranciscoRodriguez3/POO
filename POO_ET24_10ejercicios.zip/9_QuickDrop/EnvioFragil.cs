namespace QuickDrop
{
    // Nota: se usa "Fragil" sin tilde en el nombre de la clase
    // por convención de identificadores en C#.
    public class EnvioFragil : Envio
    {
        public string MaterialProteccion { get; set; }

        public EnvioFragil(string direccion, string materialProteccion) : base(direccion)
        {
            MaterialProteccion = materialProteccion;
        }

        public override string ProcesarEntrega()
        {
            return $"Entrega FRÁGIL hacia {Direccion}: embalado con {MaterialProteccion} para evitar roturas.";
        }
    }
}
