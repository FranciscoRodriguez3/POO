namespace DigitalKitchen
{
    public class Ensalada : Plato
    {
        public string TipoAderezo { get; set; }

        public Ensalada(string nombrePlato, string tipoAderezo) : base(nombrePlato)
        {
            TipoAderezo = tipoAderezo;
        }

        public override string Preparar()
        {
            return $"Mezclando la ensalada {NombrePlato} con aderezo {TipoAderezo}.";
        }
    }
}
