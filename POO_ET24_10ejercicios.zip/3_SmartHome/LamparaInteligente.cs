namespace SmartHome
{
    public class LamparaInteligente : Dispositivo
    {
        public string ColorLed { get; set; }

        public LamparaInteligente(string habitacion, string colorLed) : base(habitacion)
        {
            ColorLed = colorLed;
        }

        public override string EjecutarFuncion()
        {
            return $"La lámpara inteligente de {Habitacion} se enciende en color {ColorLed}.";
        }
    }
}
