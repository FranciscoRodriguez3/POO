using System;

namespace OrquestaVirtual
{
    public class Guitarra : Instrumento
    {
        private int numeroCuerdas;

        public int NumeroCuerdas
        {
            get { return numeroCuerdas; }
            set
            {
                if (value <= 0)
                    throw new ArgumentException("El número de cuerdas debe ser mayor a 0.");
                numeroCuerdas = value;
            }
        }

        public Guitarra(string modelo, int numeroCuerdas) : base(modelo)
        {
            NumeroCuerdas = numeroCuerdas;
        }

        public override string TocarNota()
        {
            return $"La guitarra {Modelo} rasguea un acorde con sus {NumeroCuerdas} cuerdas.";
        }
    }
}
