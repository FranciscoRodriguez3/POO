namespace DigitalKitchen
{
    public class Pizza : Plato
    {
        public string TipoMasa { get; set; }

        public Pizza(string nombrePlato, string tipoMasa) : base(nombrePlato)
        {
            TipoMasa = tipoMasa;
        }

        public override string Preparar()
        {
            return $"Horneando la pizza {NombrePlato} con masa {TipoMasa}.";
        }
    }
}
