using System;

namespace OrquestaVirtual
{
    public class Instrumento
    {
        private string modelo;

        public string Modelo
        {
            get { return modelo; }
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentException("El modelo no puede estar vacío.");
                modelo = value;
            }
        }

        public Instrumento(string modelo)
        {
            Modelo = modelo;
        }

        public virtual string TocarNota()
        {
            return $"El instrumento {Modelo} suena una nota genérica.";
        }
    }
}
