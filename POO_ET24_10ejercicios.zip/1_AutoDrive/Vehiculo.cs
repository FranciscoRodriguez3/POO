using System;

namespace AutoDrive
{
    // Clase base: define lo común a todos los vehículos
    public class Vehiculo
    {
        // Campo privado (encapsulado)
        private string marca;

        // Propiedad pública con validación en el set
        public string Marca
        {
            get { return marca; }
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentException("La marca no puede estar vacía.");
                marca = value;
            }
        }

        // Constructor: obliga a setear la marca al crear el objeto
        public Vehiculo(string marca)
        {
            Marca = marca;
        }

        // "virtual" permite que las clases hijas lo redefinan
        public virtual string Arrancar()
        {
            return $"El vehículo de marca {Marca} está arrancando.";
        }
    }
}
