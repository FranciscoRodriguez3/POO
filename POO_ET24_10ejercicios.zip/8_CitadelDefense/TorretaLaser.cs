using System;

namespace CitadelDefense
{
    public class TorretaLaser : Torreta
    {
        private int cargaBateria;

        public int CargaBateria
        {
            get { return cargaBateria; }
            set
            {
                if (value < 0 || value > 100)
                    throw new ArgumentException("La carga de batería debe estar entre 0 y 100.");
                cargaBateria = value;
            }
        }

        public TorretaLaser(string ubicacion, int cargaBateria) : base(ubicacion)
        {
            CargaBateria = cargaBateria;
        }

        public override string Disparar()
        {
            return $"La torreta láser en {Ubicacion} dispara un rayo con {CargaBateria}% de batería.";
        }
    }
}
