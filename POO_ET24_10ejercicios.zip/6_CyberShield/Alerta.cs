using System;

namespace CyberShield
{
    public class Alerta
    {
        private string codigo;

        public string Codigo
        {
            get { return codigo; }
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentException("El código de alerta no puede estar vacío.");
                codigo = value;
            }
        }

        public Alerta(string codigo)
        {
            Codigo = codigo;
        }

        public virtual string DispararProtocolo()
        {
            return $"Alerta {Codigo}: protocolo genérico activado.";
        }
    }
}
