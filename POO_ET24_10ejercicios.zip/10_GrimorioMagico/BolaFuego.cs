using System;

namespace GrimorioMagico
{
    public class BolaFuego : Hechizo
    {
        private int temperaturaC;

        public int TemperaturaC
        {
            get { return temperaturaC; }
            set
            {
                if (value <= 0)
                    throw new ArgumentException("La temperatura debe ser mayor a 0°C.");
                temperaturaC = value;
            }
        }

        public BolaFuego(string encantamiento, int temperaturaC) : base(encantamiento)
        {
            TemperaturaC = temperaturaC;
        }

        public override string Lanzar()
        {
            return $"¡{Encantamiento}! Una bola de fuego a {TemperaturaC}°C sale disparada.";
        }
    }
}
