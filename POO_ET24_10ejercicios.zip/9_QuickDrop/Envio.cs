using System;

namespace QuickDrop
{
    public class Envio
    {
        private string direccion;

        public string Direccion
        {
            get { return direccion; }
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentException("La dirección no puede estar vacía.");
                direccion = value;
            }
        }

        public Envio(string direccion)
        {
            Direccion = direccion;
        }

        public virtual string ProcesarEntrega()
        {
            return $"Procesando entrega estándar hacia {Direccion}.";
        }
    }
}
